
const todoForm = document.getElementById('todo-form');
const todoInput = document.getElementById('todo-input');
const todoList = document.getElementById('todo-list');


document.addEventListener('DOMContentLoaded', loadTasks);


todoForm.addEventListener('submit', function (e) {
    e.preventDefault();
    addTask(todoInput.value);
    todoInput.value = ''; 
});


function addTask(taskText) {
    if (taskText.trim() === '') return;

    const li = document.createElement('li');


    const taskSpan = document.createElement('span');
    taskSpan.textContent = taskText;

 
    const editBtn = document.createElement('button');
    editBtn.textContent = 'Edit';
    editBtn.classList.add('edit-btn');
    editBtn.addEventListener('click', () => editTask(li, taskSpan));


    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.classList.add('delete-btn');
    deleteBtn.addEventListener('click', () => {
        todoList.removeChild(li);
        saveTasks();
    });


    li.appendChild(taskSpan);
    li.appendChild(editBtn);
    li.appendChild(deleteBtn);
    todoList.appendChild(li);

    saveTasks();
}


function editTask(li, taskSpan) {
    const editInput = document.createElement('input');
    editInput.type = 'text';
    editInput.value = taskSpan.textContent;

    const saveBtn = document.createElement('button');
    saveBtn.textContent = 'Save';
    saveBtn.classList.add('edit-btn');
    saveBtn.addEventListener('click', () => {
        taskSpan.textContent = editInput.value;
        li.replaceChild(taskSpan, editInput);
        li.replaceChild(editBtn, saveBtn);
        saveTasks();
    });

    li.replaceChild(editInput, taskSpan);
    li.replaceChild(saveBtn, li.querySelector('.edit-btn'));
}

function saveTasks() {
    const tasks = [];
    todoList.querySelectorAll('li').forEach(li => {
        const taskText = li.querySelector('span').textContent;
        tasks.push(taskText);
    });
    localStorage.setItem('tasks', JSON.stringify(tasks));
}


function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.forEach(taskText => addTask(taskText));
}
